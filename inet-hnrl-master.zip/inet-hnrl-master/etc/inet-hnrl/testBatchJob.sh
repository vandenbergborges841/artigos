#!/bin/sh
#$ -cwd

#DATE=`date`
#echo "Task started at $DATE"
#./run -f basicHTTP.ini -u Cmdenv -c TdmPonWithHttp -r 0
cd /users/kks/inet/examples/ngoa/ecr
/users/kks/inet/examples/ngoa/ecr/52
echo "Task has been finished!"
