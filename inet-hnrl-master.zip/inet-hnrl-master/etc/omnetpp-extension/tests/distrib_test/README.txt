distribution_test
=================

Test of various probability distributions
