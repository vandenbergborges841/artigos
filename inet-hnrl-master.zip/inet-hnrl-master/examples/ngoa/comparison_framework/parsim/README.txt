comparsion_framework parallel simulation
========================================

Shortdesc:	parallel simulation extension of 'comparison_framework'
Author:		Kyeong Soo (Joseph) Kim (kyeongsoo.kim@gmail.com)
License:	GPL
Requires:	OMNeT++ (version 4.1 or later)
            INET-HNRL (release inet-hnrl_20100705 or later)


1. OMNeT++ Installation



2. INET-HNRL Installation



3. Parallel Run
